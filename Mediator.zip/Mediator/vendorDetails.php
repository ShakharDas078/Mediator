<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendor Details</title>
    <link rel="stylesheet" href="first.css"> 
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
<div class="dashboard-container">
        <div class="sidebar">
            <ul>
                <li><a href="first.php" class="active">Home</a></li>
                <li><a href="payment.php">Payment Details</a></li>
                <li><a href="product.php">Product</a></li>
                <li style="float:right"><a class="active" href="#about">About</a></li>
               
            </ul>
           
        </div>
    </div>
    <h2>Vendor Details</h2>
    <table>
        <tr>
            <th>Vendor ID</th>
            <th>Name</th>
            <th>Email</th>
            
        </tr>
        <?php
        include("connection.php");

        $sql = "SELECT * FROM vendor";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["vId"] . "</td>";
                echo "<td>" . $row["vName"] . "</td>";
                echo "<td>" . $row["vEmail"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No vendors found</td></tr>";
        }
        $conn->close();
        ?>
    </table>
</body>
</html>
