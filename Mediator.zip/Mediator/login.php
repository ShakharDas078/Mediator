<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="container">
        <form method="post"> 
            <h2>Login Form</h2>
            <div class="input">
                <input type="tel" id="phone" name="phone" placeholder="Phone Number" required><br>
                <input type="password" id="password" name="password" placeholder="Password" required><br>
                <div class="redio">
                    <label>Select User Type:</label>
                    <input type="radio" id="vendorRadio" name="userType" value="Vendor">
                    <label for="vendorRadio">Vendor</label>
                    <input type="radio" id="customerRadio" name="userType" value="customer">
                    <label for="customerRadio">Customer</label>
                </div>
            </div>
            <button type="submit">Login</button>
            <a href="users.php">Sign Up</a><br>
        </form>
    </div>
</body>
</html>

<?php
include("connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $userType = $_POST['userType'];
    
    if ($userType === 'Vendor') {
        $sql = "SELECT * FROM vendor WHERE vPhone='$phone' AND vPassword='$password'";
        $redirectPage = 'views.php'; 
    } elseif ($userType === 'customer') {
        $sql = "SELECT * FROM customer WHERE cPhone='$phone' AND cPassword='$password'";
        $redirectPage = 'customerV.php'; 
    }

    if (!empty($sql)) {
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            header("Location: $redirectPage");
            exit();
        } else {
            echo "Invalid phone number or password";
        }
    } else {
        echo "Invalid user type";
    }
}

$conn->close();
?>
