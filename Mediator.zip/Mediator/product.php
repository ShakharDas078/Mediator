<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
</head>
<body>
    <h2>Add Product</h2>
    <form  method="post">
        <label for="pName">Product Name:</label><br>
        <input type="text" id="pName" name="pName" required><br>
        
        <label for="vId">Vendor ID:</label><br>
        <input type="number" id="vId" name="vId" required><br>
        
        <label for="pPrice">Price:</label><br>
        <input type="number" id="pPrice" name="pPrice" min="0" step="0.01" required><br>
        
        <label for="pDescription">Description:</label><br>
        <textarea id="pDescription" name="pDescription"></textarea><br>
        
        <label for="pType">Product Type:</label><br>
        <input type="text" id="pType" name="pType" required><br>
        
        <button type="submit">Add Product</button>
    </form>
</body>
</html>


<?php
include("connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pName = $_POST["pName"];
    $vId = $_POST["vId"];
    $pPrice = $_POST["pPrice"];
    $pDescription = $_POST["pDescription"];
    $pType = $_POST["pType"];

    $sql = "INSERT INTO product (pName, vId, pPrice, pDescription, pType) VALUES ('$pName', '$vId', '$pPrice', '$pDescription', '$pType')";

    if ($conn->query($sql) === TRUE) {
        echo "New product added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
