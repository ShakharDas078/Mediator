<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendor Registration Form</title>
</head>
<body>
    <h2>Vendor Registration Form</h2>
    <form  method="post">
      
        <input type="text" id="vName" name="vName" placeholder="Enter Name" required><br>

        <input type="email" id="vEmail" name="vEmail" placeholder="Enter Email" required><br>

        <input type="text" id="vPhone" name="vPhone" placeholder="Enter Phone" required><br>

        <input type="password" id="vPassword" name="vPassword" placeholder="Enter Password" required><br>

        <input type="text" id="vPageUrl" name="vPageUrl" placeholder="Enter Page URL" required><br>

        <button type="submit">Register</button>
    </form>
</body>
</html>


<?php
include("connection.php");
function generateVendorId() {
    $year = date('y'); 
    $month = date('m'); 
    $random = mt_rand(1000, 9999);

  
    $vendorId = $year . $month . $random;

    return $vendorId;
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $vName = $_POST["vName"];
    $vEmail = $_POST["vEmail"];
    $vPhone = $_POST["vPhone"];
    $vPassword = $_POST["vPassword"];
    $vPageUrl = $_POST["vPageUrl"];

  
    $vId = generateVendorId();

    
    $sql = "INSERT INTO vendor (vId, vName, vEmail, vPhone, vPassword, vPageUrl) VALUES ('$vId', '$vName', '$vEmail', '$vPhone', '$vPassword', '$vPageUrl')";

    if ($conn->query($sql) === TRUE) {
        header("Location: views.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


$conn->close();
?>
