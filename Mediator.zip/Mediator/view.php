<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mediator";

$conn = new mysqli($servername, $username, $password, $dbname);

 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Proposal</title>
    <link rel="stylesheet" href="view.css"> 
</head>
<body>
    <h2>View Proposal</h2>
    <table>
        <tr>
            <th>Proposal ID</th>
            <th>Proposal Name</th>
            <th>Seller ID</th>
            <th>Price</th>
            <th>Product Description</th>
        </tr>
        <?php
        $sql = "SELECT * FROM proposal";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".$row['pId']."</td>";
                echo "<td>".$row['pName']."</td>";
                echo "<td>".$row['sId']."</td>";
                echo "<td>".$row['pPrice']."</td>";
                echo "<td>".$row['pDescription']."</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No proposals found</td></tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
