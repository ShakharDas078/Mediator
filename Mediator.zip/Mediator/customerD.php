<?php

include("connection.php");


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM products";
$result = mysqli_query($conn, $sql);

if (isset($_POST['submit'])) {
    
    if (isset($_POST['selectedProducts'])) {
 
        foreach ($_POST['selectedProducts'] as $productId) {
            
        }
        
        
        echo "Order placed successfully!";
    } else {
        echo "No products selected.";
    }
} else {
    
    echo "Form submission error.";
}

if ($result) {
    
    if (mysqli_num_rows($result) > 0) {
      
        echo "<form method='POST' action='process_order.php'>";
        echo "<table border='1'>";
        echo "<tr><th>Select</th><th>Product ID</th><th>Product Name</th><th>Price</th></tr>";

        
        while ($row = mysqli_fetch_assoc($result)) {
           
            echo "<tr>";
            echo "<td><input type='checkbox' name='selectedProducts[]' value='" . $row['product_id'] . "'></td>";
            echo "<td>" . $row['product_id'] . "</td>";
            echo "<td>" . $row['product_name'] . "</td>";
            echo "<td>" . $row['price'] . "</td>";
            echo "</tr>";
        }

        
        echo "</table>";
        echo "<input type='submit' name='submit' value='Place Order'>";
        echo "</form>";
    } else {
        echo "No products available.";
    }
} else {
    
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}


$conn->close();
?>

