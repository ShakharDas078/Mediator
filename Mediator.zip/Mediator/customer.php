
<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>Customer Registration Form</title>
</head>
<body>
    <h2>Customer Registration Form</h2>
    <form  method="post">
      
        <input type="text" id="cName" name="cName" placeholder="Enter Name" required><br>

        <input type="email" id="cEmail" name="cEmail" placeholder="Enter Email" required><br>

        <input type="tel" id="cPhone" name="cPhone" placeholder="Enter Phone" required><br>

        <input type="password" id="cPassword" name="cPassword" placeholder="Enter Password" required><br>

        <textarea id="cAddress" name="cAddress" placeholder="Enter Address" required></textarea><br>

        <button type="submit">Register</button>
    </form>
</body>
</html>


<?php
include("connection.php");

function generateSID() {
    $year = date('y');
    $month = date('m');
    $random = mt_rand(10, 99);
    
    $cId = $year . $month . $random;
    return $cId;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cName = $_POST["cName"];
    $cEmail = $_POST["cEmail"];
    $cPhone = $_POST["cPhone"];
    $cPassword = $_POST["cPassword"];
    $cAddress = $_POST["cAddress"];

    $cId = generateSID();

    $sql = "INSERT INTO customer (cId, cName, cEmail, cPhone, cPassword, cAddress) VALUES ('$cId', '$cName', '$cEmail', '$cPhone', '$cPassword', '$cAddress')";

    if ($conn->query($sql) === TRUE) {
        header("Location:customerV.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
