<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>first</title>
    <link rel="stylesheet" href="first.css"> 
</head>
<body>
 
    <div class="dashboard-container">
        <div class="sidebar">
            <ul>
                <li><a href="first.php" class="active">Home</a></li>
                <li><a href="users.php">Payment Details</a></li>
                <li><a href="vendorDetails.php">View Details</a></li>
                <li style="float:right"><a class="active" href="#about">About</a></li>
               
            </ul>
           
        </div>
    </div>
        
</body>
</html>
