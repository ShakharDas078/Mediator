

<?php
session_start();

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "media";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Fetch user data from database
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $username;
            echo "Login successful!";
        } else {
            echo "Invalid username or password!";
        }
    } else {
        echo "Invalid username or password!";
    }
}

$conn->close();
?>
     Login code
/*
<!DOCTYPE html>
<html>

<head>
	<title>login</title>
	<link rel="stylesheet" href="login.css">
</head>

<body>
<div class="container">
  <form action="login.php" method="post">
    <h2>Login Form</h2>
    <div class="input">
	 <input type="tel" id="phone" name="phone" placeholder="Phone Number" required>
    <input type="password" id="password" name="password" placeholder="Password"  required><br>
    <div class="redio">
                    <label>Select User Type:</label>
                    <input type="radio" id="sellerRadio" name="userType" value="seller">
                    <label for="sellerRadio">Seller</label>
                    <input type="radio" id="buyerRadio" name="userType" value="buyer">
                    <label for="buyerRadio">Buyer</label>
                </div>
    </div>
    <button type="submit">Login</button>
	<a href="users.php">Sign Up</a><br>
  </form>
</div>
<script>
        document.getElementById('loginForm').addEventListener('submit', function () {
            var userType = document.querySelector('input[name="userType"]:checked').value;
            if (userType === 'seller') {
                this.action = 'proposal.php';
            } else if (userType === 'buyer') {
                this.action = 'rjr.php';
            }
        });
    </script>
</body>

</html>



<?php
session_start();

$host = "localhost";
$username = "root"; 
$password = ""; 
$database = "mediator"; 


$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $userType = $_POST['userType'];

    /* Sanitize inputs to prevent SQL injection
    $phone = mysqli_real_escape_string($conn, $phone);
    $password = mysqli_real_escape_string($conn, $password);
    $userType = mysqli_real_escape_string($conn, $userType);*/

    if ($userType === 'seller') {
        $sql = "SELECT * FROM seller WHERE phone='$phone' AND password='$password'";
        $redirectPage = 'proposal.php'; 
    } elseif ($userType === 'buyer') {
        $sql = "SELECT * FROM buyer WHERE phone='$phone' AND password='$password'";
        $redirectPage = 'buyer.php'; 
    }

    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        // Login successful
        header("Location: $redirectPage");
        exit();
    } else {

        echo "Invalid phone number or password";
    }
}
?>
*/